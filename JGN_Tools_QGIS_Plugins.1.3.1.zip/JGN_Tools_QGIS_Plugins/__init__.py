def classFactory(iface):
    from .plugin import CablePassthroughPlugin
    return CablePassthroughPlugin(iface)
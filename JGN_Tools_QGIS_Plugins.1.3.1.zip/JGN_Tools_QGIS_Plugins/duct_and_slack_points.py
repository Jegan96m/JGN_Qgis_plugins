import os

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

from qgis.PyQt.QtCore import QCoreApplication, QVariant

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
    QgsWkbTypes,
    QgsGeometry,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsDistanceArea,
    QgsProject,
    QgsSpatialIndex
)


class DuctAndSlackPoints(QgsProcessingAlgorithm):

    INPUT = 'INPUT'
    DUCT_POINTS = 'DUCT_POINTS'
    SLACK_POINTS = 'SLACK_POINTS'
    START_OFFSET = 'START_OFFSET'
    END_OFFSET = 'END_OFFSET'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return DuctAndSlackPoints()

    def name(self):
        return 'duct_and_slack_points'

    def displayName(self):
        return self.tr('Duct & Slack Points by JGN')

    # ⬇ Empty group = appears directly under "Cable Passthrough"
    def group(self):
        return ''

    def groupId(self):
        return ''
    
     # ⬇ ADD THIS
    def icon(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), 'icon.png'
        )
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr(
            'Creates point features from line start/end points.\n\n'
            'Duct Points and Slack Points can be used independently '
            'or together.\n\n'
            'Duct Points only:\n'
            '- Creates Start Points\n'
            '- Uses Start Offset\n'
            '- Adds Duct, Duct color, Numbering and Page fields\n\n'
            'Slack Points only:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Slackloop field with value 50\n\n'
            'Duct Points + Slack Points:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Duct, Duct color, Numbering, Page and Slackloop fields.'
        )

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Input line layer'),
                [QgsProcessing.TypeVectorLine]
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.DUCT_POINTS,
                self.tr('Create Duct Points'),
                defaultValue=True
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SLACK_POINTS,
                self.tr('Create Slack Points'),
                defaultValue=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.START_OFFSET,
                self.tr('Start Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.END_OFFSET,
                self.tr('End Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Output point layer'),
                QgsProcessing.TypeVectorPoint
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(
            parameters,
            self.INPUT,
            context
        )

        if source is None:
            raise QgsProcessingException(
                self.tr('Could not load the input line layer.')
            )

        duct_points = self.parameterAsBool(
            parameters, self.DUCT_POINTS, context
        )
        slack_points = self.parameterAsBool(
            parameters, self.SLACK_POINTS, context
        )
        start_offset_deg = self.parameterAsDouble(
            parameters, self.START_OFFSET, context
        )
        end_offset_deg = self.parameterAsDouble(
            parameters, self.END_OFFSET, context
        )

        if not duct_points and not slack_points:
            raise QgsProcessingException(
                self.tr(
                    'Please enable at least one option: '
                    'Duct Points or Slack Points.'
                )
            )

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')

        metres_per_degree = 111319.9

        start_offset_m = (
            start_offset_deg * metres_per_degree
        )
        end_offset_m = (
            end_offset_deg * metres_per_degree
        )

        start_offset_m = da.convertLengthMeasurement(
            start_offset_m,
            source.sourceCrs().mapUnits()
        )
        end_offset_m = da.convertLengthMeasurement(
            end_offset_m,
            source.sourceCrs().mapUnits()
        )

        # ---------------------------------------------------------
        # Find Grid_atlas layer + spatial index
        # ---------------------------------------------------------
        grid_layers = QgsProject.instance().mapLayersByName(
            'Grid_atlas'
        )
        grid_layer = grid_layers[0] if grid_layers else None

        grid_index = None
        if grid_layer is not None:
            grid_index = QgsSpatialIndex(
                grid_layer.getFeatures()
            )

        def get_page(point_geometry):

            if grid_layer is None or grid_index is None:
                return None

            candidate_ids = grid_index.intersects(
                point_geometry.boundingBox()
            )

            for grid_id in candidate_ids:

                grid_feature = grid_layer.getFeature(grid_id)

                if not grid_feature.isValid():
                    continue

                grid_geometry = grid_feature.geometry()

                if grid_geometry is None or grid_geometry.isEmpty():
                    continue

                if grid_geometry.intersects(point_geometry):
                    return grid_feature['ID']

            return None

        # ---------------------------------------------------------
        # Output fields
        # ---------------------------------------------------------
        fields = source.fields()

        if duct_points:
            fields.append(QgsField('Duct', QVariant.Int))
            fields.append(
                QgsField('Duct color', QVariant.String, 'string', 50)
            )
            fields.append(QgsField('Numbering', QVariant.Int))
            fields.append(QgsField('Page', QVariant.Int))

        if slack_points:
            fields.append(QgsField('Slackloop', QVariant.Int))

        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.Point,
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(
                self.tr('Could not create output layer.')
            )

        v_layer_index = source.fields().indexOf('v_layer')

        total = source.featureCount()
        progress_step = 100.0 / total if total > 0 else 0

        for current, feature in enumerate(source.getFeatures()):

            if feedback.isCanceled():
                break

            geom = feature.geometry()

            if geom is None or geom.isEmpty():
                continue

            line_length = geom.length()

            if line_length <= 0:
                continue

            duct_color_value = None

            if duct_points and v_layer_index >= 0:
                v_layer_value = feature.attribute(v_layer_index)

                if v_layer_value is not None:
                    v_layer_value = str(v_layer_value).strip()

                    if v_layer_value == 'Backbone':
                        duct_color_value = '1'
                    elif v_layer_value == 'F1 Lateral':
                        duct_color_value = '2'
                    elif v_layer_value == 'F2 Distribution':
                        duct_color_value = '3'

            # --------------------------------------------------
            # START POINT
            # --------------------------------------------------
            start_dist = min(start_offset_m, line_length)
            start_geom = geom.interpolate(start_dist)

            if not start_geom.isEmpty():

                start_point = start_geom.asPoint()

                start_feature = QgsFeature(fields)
                start_point_geometry = QgsGeometry.fromPointXY(
                    start_point
                )
                start_feature.setGeometry(start_point_geometry)

                attributes = feature.attributes()

                if duct_points:
                    attributes.append(None)                # Duct
                    attributes.append(duct_color_value)    # Duct color
                    attributes.append(None)                # Numbering
                    attributes.append(
                        get_page(start_point_geometry)    # Page
                    )

                if slack_points:
                    attributes.append(50)

                start_feature.setAttributes(attributes)
                sink.addFeature(
                    start_feature, QgsFeatureSink.FastInsert
                )

            # --------------------------------------------------
            # END POINT
            # --------------------------------------------------
            if slack_points:

                end_dist = max(0, line_length - end_offset_m)
                end_geom = geom.interpolate(end_dist)

                if not end_geom.isEmpty():

                    end_point = end_geom.asPoint()

                    end_feature = QgsFeature(fields)
                    end_point_geometry = QgsGeometry.fromPointXY(
                        end_point
                    )
                    end_feature.setGeometry(end_point_geometry)

                    end_attributes = feature.attributes()

                    if duct_points:
                        end_attributes.append(None)
                        end_attributes.append(duct_color_value)
                        end_attributes.append(None)
                        end_attributes.append(
                            get_page(end_point_geometry)
                        )

                    end_attributes.append(50)

                    end_feature.setAttributes(end_attributes)
                    sink.addFeature(
                        end_feature, QgsFeatureSink.FastInsert
                    )

            feedback.setProgress(
                int(current * progress_step)
            )

        return {self.OUTPUT: dest_id}
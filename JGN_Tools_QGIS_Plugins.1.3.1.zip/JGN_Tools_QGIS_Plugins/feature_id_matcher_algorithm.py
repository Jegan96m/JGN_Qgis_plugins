"""
***************************************************************************
* Cable Passthrough (Attribute Tool) by JGN
* Supports F1 / F2 profiles and additional field selection.
* Preserves Input 1 geometry and unselected attributes.
* Automatically replaces Input 1 ID with Input 2 ID.
* Unmatched features receive ID = Not matched.
***************************************************************************
"""

import os

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

from qgis.core import (
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsSpatialIndex,
    QgsCoordinateTransform,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterField,
)


def _icon_path():
    """Return the absolute path to icon.png inside the plugin folder."""
    return os.path.join(os.path.dirname(__file__), 'icon.png')


class FeatureIDMatcher(QgsProcessingAlgorithm):

    INPUT1 = 'INPUT1'
    INPUT2 = 'INPUT2'
    PREDICATE = 'PREDICATE'
    F1 = 'F1'
    F2 = 'F2'
    EXTRA_FIELDS = 'EXTRA_FIELDS'
    OUTPUT = 'OUTPUT'

    F1_FIELDS = [
        'ID',
        'FondID',
        'Service Group',
        'Service Set',
        'Service Area',
        'Material Length',
        'Total Length',
        'ReelID',
        'Slack Loop'
    ]

    F2_FIELDS = [
        'ID',
        'FondID',
        'Service Group',
        'Service Set',
        'Service Area',
        'Material Length',
        'Total Length',
        'ReelID',
        'Slack Loop Footage'
    ]

    PREDICATES = [
        'Intersect',
        'Contain',
        'Disjoint',
        'Equal',
        'Touch',
        'Overlap',
        'Within',
        'Cross'
    ]

    PREDICATE_METHODS = [
        'intersects',
        'contains',
        'disjoint',
        'equals',
        'touches',
        'overlaps',
        'within',
        'crosses'
    ]

    def tr(self, string):
        return QCoreApplication.translate('FeatureIDMatcher', string)

    def createInstance(self):
        return FeatureIDMatcher()

    def name(self):
        return 'feature_id_matcher'

    def displayName(self):
        return self.tr('Cable Passthrough (Attribute Tool) by JGN')

    def group(self):
        return ''

    def groupId(self):
        return ''

    def icon(self):
        return QIcon(_icon_path())

    def shortHelpString(self):
        return self.tr(
            'Matches the center points of two input layers. '
            'Select F1 or F2 to copy the corresponding standard '
            'fields. Additional fields can also be selected. '
            'Selected fields replace corresponding fields in '
            'Input 1. ID is always replaced automatically. '
            'Unmatched features receive ID = Not matched.'
        )

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT1,
                self.tr('Input 1 - After Merge & Split Cable layer'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT2,
                self.tr('Input 2 - Before Merge & Split Cable layer'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.PREDICATE,
                self.tr('Geometric predicate'),
                options=self.PREDICATES,
                allowMultiple=True,
                defaultValue=[0]
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.F1,
                self.tr('F1'),
                defaultValue=False
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.F2,
                self.tr('F2'),
                defaultValue=False
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.EXTRA_FIELDS,
                self.tr('Additional fields to copy from Input 2'),
                parentLayerParameterName=self.INPUT2,
                type=QgsProcessingParameterField.Any,
                allowMultiple=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Output layer')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source1 = self.parameterAsSource(
            parameters, self.INPUT1, context
        )
        source2 = self.parameterAsSource(
            parameters, self.INPUT2, context
        )

        if source1 is None:
            raise QgsProcessingException(
                self.invalidSourceError(parameters, self.INPUT1)
            )
        if source2 is None:
            raise QgsProcessingException(
                self.invalidSourceError(parameters, self.INPUT2)
            )

        fields1 = source1.fields()
        fields2 = source2.fields()

        def find_field_index(fields, field_name):
            for i, field in enumerate(fields):
                if field.name().lower() == field_name.lower():
                    return i
            return -1

        index_id1 = find_field_index(fields1, 'ID')
        index_id2 = find_field_index(fields2, 'ID')

        if index_id1 < 0:
            raise QgsProcessingException(
                "Input 1 does not contain an 'ID' field."
            )
        if index_id2 < 0:
            raise QgsProcessingException(
                "Input 2 does not contain an 'ID' field."
            )

        use_f1 = self.parameterAsBool(
            parameters, self.F1, context
        )
        use_f2 = self.parameterAsBool(
            parameters, self.F2, context
        )
        extra_fields = self.parameterAsFields(
            parameters, self.EXTRA_FIELDS, context
        )

        if not use_f1 and not use_f2 and not extra_fields:
            raise QgsProcessingException(
                'Please select F1, F2, or at least one '
                'additional field to copy.'
            )

        selected_fields = []

        if use_f1:
            selected_fields.extend(self.F1_FIELDS)

        if use_f2:
            for field_name in self.F2_FIELDS:
                if field_name.lower() not in [
                    name.lower() for name in selected_fields
                ]:
                    selected_fields.append(field_name)

        for field_name in extra_fields:
            if field_name.lower() not in [
                name.lower() for name in selected_fields
            ]:
                selected_fields.append(field_name)

        selected_predicates = self.parameterAsEnums(
            parameters, self.PREDICATE, context
        )
        predicate_methods = [
            self.PREDICATE_METHODS[i]
            for i in selected_predicates
            if 0 <= i < len(self.PREDICATE_METHODS)
        ]
        if not predicate_methods:
            predicate_methods = ['intersects']

        replace_fields = []

        for field_name in selected_fields:
            if field_name.lower() == 'id':
                continue

            index1 = find_field_index(fields1, field_name)
            index2 = find_field_index(fields2, field_name)

            if index2 < 0:
                raise QgsProcessingException(
                    f"Field '{field_name}' does not exist in "
                    "Input 2. Check the selected F1/F2 profile "
                    "and additional fields."
                )
            if index1 < 0:
                raise QgsProcessingException(
                    f"Field '{field_name}' does not exist in "
                    "Input 1. Selected fields must exist in "
                    "both input layers."
                )

            replace_fields.append((index1, index2, field_name))

        output_fields = QgsFields()

        for field in fields1:
            if field.name().lower() == 'id':
                output_fields.append(
                    QgsField(
                        field.name(),
                        QVariant.String,
                        'string',
                        max(field.length(), 1000)
                    )
                )
            else:
                output_fields.append(QgsField(field))

        crs1 = source1.sourceCrs()
        crs2 = source2.sourceCrs()

        transform = None
        if crs1 != crs2:
            transform = QgsCoordinateTransform(
                crs2, crs1, context.transformContext()
            )

        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            output_fields,
            source1.wkbType(),
            crs1
        )

        if sink is None:
            raise QgsProcessingException(
                self.invalidSinkError(parameters, self.OUTPUT)
            )

        spatial_index = QgsSpatialIndex()
        center_geometries = {}
        reference_features = {}

        features2 = list(source2.getFeatures())
        total2 = len(features2)

        for count, feature2 in enumerate(features2):

            if feedback.isCanceled():
                return {self.OUTPUT: dest_id}

            if not feature2.hasGeometry():
                continue

            geometry2 = feature2.geometry()
            if geometry2.isNull() or geometry2.isEmpty():
                continue

            center2 = geometry2.centroid()
            if center2.isNull() or center2.isEmpty():
                continue

            if transform is not None:
                center2 = QgsGeometry(center2)
                center2.transform(transform)

            center_geometries[feature2.id()] = center2
            reference_features[feature2.id()] = feature2

            index_feature = QgsFeature()
            index_feature.setId(feature2.id())
            index_feature.setGeometry(center2)
            spatial_index.addFeature(index_feature)

            if total2:
                feedback.setProgress(int((count + 1) / total2 * 30))

        features1 = list(source1.getFeatures())
        total1 = len(features1)

        matched_count = 0
        unmatched_count = 0

        for count, feature1 in enumerate(features1):

            if feedback.isCanceled():
                break

            match = None

            if feature1.hasGeometry():
                geometry1 = feature1.geometry()

                if not geometry1.isNull() and not geometry1.isEmpty():
                    center1 = geometry1.centroid()

                    if not center1.isNull() and not center1.isEmpty():

                        if 'disjoint' in predicate_methods:
                            candidate_ids = list(
                                center_geometries.keys()
                            )
                        else:
                            candidate_ids = spatial_index.intersects(
                                center1.boundingBox()
                            )

                        for candidate_id in candidate_ids:

                            center2 = center_geometries.get(
                                candidate_id
                            )
                            if center2 is None:
                                continue

                            is_match = any(
                                getattr(center1, method)(center2)
                                for method in predicate_methods
                            )

                            if is_match:
                                match = reference_features[
                                    candidate_id
                                ]
                                break

            output_feature = QgsFeature(output_fields)

            if feature1.hasGeometry():
                output_feature.setGeometry(feature1.geometry())

            attributes = list(feature1.attributes())

            if match is not None:
                matched_id = match.attribute(index_id2)
                attributes[index_id1] = (
                    None if matched_id is None
                    else str(matched_id)
                )

                for index1, index2, field_name in replace_fields:
                    attributes[index1] = match.attribute(index2)

                matched_count += 1
            else:
                attributes[index_id1] = 'Not matched'
                unmatched_count += 1

            output_feature.setAttributes(attributes)

            sink.addFeature(
                output_feature, QgsFeatureSink.FastInsert
            )

            if total1:
                feedback.setProgress(
                    30 + int((count + 1) / total1 * 70)
                )

        feedback.pushInfo(
            f'Total Input 1 features: {total1}'
        )
        feedback.pushInfo(
            f'Matched features: {matched_count}'
        )
        feedback.pushInfo(
            f'Unmatched features: {unmatched_count}'
        )
        feedback.pushInfo(f'F1 selected: {use_f1}')
        feedback.pushInfo(f'F2 selected: {use_f2}')
        feedback.pushInfo(
            f'Additional fields selected: {len(extra_fields)}'
        )
        feedback.pushInfo(
            f'Fields copied (excluding automatic ID): '
            f'{len(replace_fields)+1}'
        )

        return {self.OUTPUT: dest_id}
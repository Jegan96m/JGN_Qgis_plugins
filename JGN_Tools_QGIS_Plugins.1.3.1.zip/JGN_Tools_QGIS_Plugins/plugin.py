import os

from qgis.core import QgsApplication, QgsProcessingProvider
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

from .feature_id_matcher_algorithm import FeatureIDMatcher
from .duct_and_slack_points import DuctAndSlackPoints
from .vetro_projection_tool import RoundCoordinatesAlgorithm
from .split_vector_layer import SplitVectorLayer


def _icon_path():
    """Return the absolute path to icon.png inside the plugin folder."""
    return os.path.join(os.path.dirname(__file__), 'icon.png')


class CablePassthroughPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action = None

    def initProcessing(self):
        self.provider = CablePassthroughProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

        self.action = QAction(
            QIcon(_icon_path()),
            'JGN Tools',
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu(
            '&JGN Tools', self.action
        )

    def unload(self):
        self.iface.removePluginVectorMenu(
            '&JGN Tools', self.action
        )
        self.iface.removeToolBarIcon(self.action)

        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(
                self.provider
            )
            self.provider = None

    def run(self):
        # Opens the first tool (FeatureIDMatcher) by default.
        # Users can access both tools from the Processing Toolbox.
        alg_id = 'cable_passthrough:feature_id_matcher'
        alg = QgsApplication.processingRegistry().algorithmById(
            alg_id
        )

        if alg is None:
            self.iface.messageBar().pushCritical(
                'JGN Tools',
                'Algorithm not found in Processing registry.'
            )
            return

        from qgis import processing
        try:
            processing.execAlgorithmDialog(alg_id, {})
        except Exception as e:
            self.iface.messageBar().pushCritical(
                'JGN Tools', str(e)
            )


class CablePassthroughProvider(QgsProcessingProvider):

    def id(self):
        return 'cable_passthrough'

    def name(self):
        return 'JGN Tools'

    def longName(self):
        return 'JGN Tools'

    def icon(self):
        return QIcon(_icon_path())

    def loadAlgorithms(self):
        self.addAlgorithm(FeatureIDMatcher())
        self.addAlgorithm(DuctAndSlackPoints())
        self.addAlgorithm(RoundCoordinatesAlgorithm())
        self.addAlgorithm(SplitVectorLayer())
import os
import re
import gc

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
    QgsProcessingException,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsFeature,
    QgsFeatureRequest,
    QgsExpression,
    QgsWkbTypes,
    NULL
)

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis import processing


class SplitVectorLayer(QgsProcessingAlgorithm):
    """
    Splits a vector layer into separate files based on unique field values.

    Supported formats:
    - GeoJSON
    - Shapefile
    - GeoPackage
    - DXF (geometry only)

    Supports optional left-character extraction and filename suffixes.
    DXF exports use batched feature copying to reduce unnecessary
    memory allocation.
    """

    INPUT = 'INPUT'
    FIELD = 'FIELD'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    FORMAT = 'FORMAT'
    SUFFIX = 'SUFFIX'
    USE_LEFT_EXTRACTION = 'USE_LEFT_EXTRACTION'
    LEFT_CHARS = 'LEFT_CHARS'

    FORMAT_OPTIONS = [
        'GeoJSON',
        'Shapefile',
        'GeoPackage',
        'DXF'
    ]

    EXTENSIONS = {
        'GeoJSON': '.geojson',
        'Shapefile': '.shp',
        'GeoPackage': '.gpkg',
        'DXF': '.dxf'
    }

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return SplitVectorLayer()

    def name(self):
        return 'splitvectorlayer'

    def displayName(self):
        return self.tr('Split Vector Layer (Advanced) by JGN')

    # ⬇ Empty group = appears directly under "Cable Passthrough"
    def group(self):
        return ''

    def groupId(self):
        return ''

    # ⬇ ADD THIS — icon for the tool
    def icon(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), 'icon.png'
        )
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr("""
        Splits a vector layer into separate files based on unique
        values in a selected field.

        Features:
        - GeoJSON, Shapefile, GeoPackage and DXF output
        - Optional left-character extraction
        - Handles NULL field values
        - Custom filename suffix
        - DXF exports geometry only
        - Batched DXF geometry copying
        - Progress and error reporting

        Note:
        Large or complex geometries may still require substantial
        memory during DXF export.
        """)

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Input layer'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.FIELD,
                self.tr('Unique ID field'),
                parentLayerParameterName=self.INPUT,
                type=QgsProcessingParameterField.Any
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_LEFT_EXTRACTION,
                self.tr('Extract left part of field values'),
                defaultValue=False,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.LEFT_CHARS,
                self.tr('Number of characters to extract'),
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.FORMAT,
                self.tr('Output format'),
                options=self.FORMAT_OPTIONS,
                defaultValue=0
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.SUFFIX,
                self.tr('Filename suffix (after field value)'),
                optional=True,
                defaultValue=''
            )
        )

        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                self.tr('Output folder')
            )
        )

    # ---------------------------------------------------------
    # Geometry type helper
    # ---------------------------------------------------------

    def get_geometry_type(self, layer):

        wkb_type = layer.wkbType()

        if wkb_type == QgsWkbTypes.NoGeometry:
            raise QgsProcessingException(
                'The input layer has no geometry.'
            )

        geometry_type = QgsWkbTypes.displayString(wkb_type)

        if not geometry_type or geometry_type.lower() == 'unknown':
            raise QgsProcessingException(
                'Unable to determine the input geometry type.'
            )

        return geometry_type

    # ---------------------------------------------------------
    # Filename sanitization
    # ---------------------------------------------------------

    def clean_filename(self, value):

        value = str(value)

        value = re.sub(
            r'[<>:"/\\|?*\x00-\x1f]',
            '_',
            value
        )

        value = value.strip().rstrip('. ')

        value = value[:50]

        if not value:
            value = 'EMPTY'

        if re.match(
            r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$',
            value,
            re.IGNORECASE
        ):
            value = '_' + value

        return value

    # ---------------------------------------------------------
    # DXF export helper
    # ---------------------------------------------------------

    def export_dxf(
        self,
        source,
        expression,
        output_file,
        context,
        feedback
    ):

        geom_layer = None
        provider = None
        request = None
        iterator = None

        feature_count = 0

        try:

            request = QgsFeatureRequest()
            request.setFilterExpression(expression)

            geometry_type = self.get_geometry_type(source)

            source_crs = source.sourceCrs()
            crs_authid = source_crs.authid()

            if crs_authid:
                crs_definition = crs_authid
            else:
                crs_definition = source_crs.toWkt()

            geom_layer = QgsVectorLayer(
                f'{geometry_type}?crs={crs_definition}',
                'temp_dxf',
                'memory'
            )

            if not geom_layer.isValid():
                raise QgsProcessingException(
                    'Failed to create temporary DXF memory layer.'
                )

            provider = geom_layer.dataProvider()

            batch_size = 1000
            batch = []

            iterator = source.getFeatures(request)

            for feature in iterator:

                if feedback.isCanceled():
                    return False, feature_count

                new_feature = QgsFeature(geom_layer.fields())
                new_feature.setGeometry(feature.geometry())

                batch.append(new_feature)

                if len(batch) >= batch_size:

                    success, added_features = provider.addFeatures(
                        batch
                    )

                    if not success:
                        raise QgsProcessingException(
                            'Failed to add a batch of geometries '
                            'to the temporary DXF layer.'
                        )

                    feature_count += len(added_features)
                    batch.clear()

            if batch:

                success, added_features = provider.addFeatures(
                    batch
                )

                if not success:
                    raise QgsProcessingException(
                        'Failed to add the final geometry batch.'
                    )

                feature_count += len(added_features)
                batch.clear()

            if feedback.isCanceled():
                return False, feature_count

            options = QgsVectorFileWriter.SaveVectorOptions()

            options.driverName = 'DXF'
            options.fileEncoding = 'UTF-8'
            options.layerName = 'exported_geometry'

            result = QgsVectorFileWriter.writeAsVectorFormatV3(
                geom_layer,
                output_file,
                context.transformContext(),
                options
            )

            if result[0] != QgsVectorFileWriter.NoError:

                error_message = (
                    result[1]
                    if len(result) > 1
                    else 'Unknown DXF export error'
                )

                raise QgsProcessingException(
                    f'DXF export failed: {error_message}'
                )

            return True, feature_count

        finally:

            if iterator is not None:
                del iterator

            if provider is not None:
                del provider

            if geom_layer is not None:
                del geom_layer

            if request is not None:
                del request

            gc.collect()

    # ---------------------------------------------------------
    # Main processing algorithm
    # ---------------------------------------------------------

    def processAlgorithm(self, parameters, context, feedback):

        try:

            source = self.parameterAsSource(
                parameters, self.INPUT, context
            )

            if source is None:
                raise QgsProcessingException(
                    self.invalidSourceError(parameters, self.INPUT)
                )

            field_name = self.parameterAsString(
                parameters, self.FIELD, context
            )

            output_folder = self.parameterAsString(
                parameters, self.OUTPUT_FOLDER, context
            )

            format_idx = self.parameterAsEnum(
                parameters, self.FORMAT, context
            )

            output_format = self.FORMAT_OPTIONS[format_idx]
            file_extension = self.EXTENSIONS[output_format]

            suffix = self.parameterAsString(
                parameters, self.SUFFIX, context
            )

            use_left_extraction = self.parameterAsBoolean(
                parameters, self.USE_LEFT_EXTRACTION, context
            )

            left_chars = (
                self.parameterAsInt(
                    parameters, self.LEFT_CHARS, context
                )
                if use_left_extraction
                else None
            )

            if use_left_extraction and left_chars < 1:
                raise QgsProcessingException(
                    'Number of characters must be at least 1.'
                )

            field_index = source.fields().lookupField(field_name)

            if field_index < 0:
                raise QgsProcessingException(
                    f'Field not found: {field_name}'
                )

            os.makedirs(output_folder, exist_ok=True)

            # -------------------------------------------------
            # Collect unique split values
            # -------------------------------------------------

            if use_left_extraction:

                unique_values = set()

                for feature in source.getFeatures():

                    if feedback.isCanceled():
                        break

                    value = feature[field_name]

                    if value is None or value == NULL:
                        unique_values.add(None)
                    else:
                        unique_values.add(str(value)[:left_chars])

                feedback.pushInfo(
                    f'Extracted the first {left_chars} characters '
                    f'from field "{field_name}".'
                )

            else:

                unique_values = source.uniqueValues(field_index)

            unique_values = sorted(
                unique_values,
                key=lambda value: (
                    value is None or value == NULL,
                    str(value).casefold()
                    if value is not None and value != NULL
                    else ''
                )
            )

            if not unique_values:

                feedback.pushInfo(
                    'No unique values found. No files created.'
                )

                return {
                    'OUTPUT_FOLDER': output_folder,
                    'OUTPUT_LAYERS': {}
                }

            total = 100.0 / len(unique_values)
            outputs = {}

            quoted_field = (
                '"' + field_name.replace('"', '""') + '"'
            )

            suffix_clean = (
                self.clean_filename(suffix) if suffix else ''
            )

            # -------------------------------------------------
            # Process each unique value
            # -------------------------------------------------

            for i, value in enumerate(unique_values):

                if feedback.isCanceled():
                    break

                if value is None or value == NULL:

                    expression = f'{quoted_field} IS NULL'
                    value_part = 'NULL'

                elif use_left_extraction:

                    left_value = str(value)[:left_chars]
                    safe_value = left_value.replace("'", "''")

                    expression = (
                        f'left({quoted_field}, {left_chars}) '
                        f"= '{safe_value}'"
                    )

                    value_part = self.clean_filename(left_value)

                else:

                    quoted_value = QgsExpression.quotedValue(value)

                    expression = (
                        f'{quoted_field} = {quoted_value}'
                    )

                    value_part = self.clean_filename(value)

                if suffix_clean:
                    base_filename = f'{value_part}_{suffix_clean}'
                else:
                    base_filename = value_part

                output_file = os.path.join(
                    output_folder,
                    f'{base_filename}{file_extension}'
                )

                feedback.pushInfo(
                    f'Processing {i + 1}/{len(unique_values)}: '
                    f'{base_filename}'
                )

                if output_format == 'DXF':

                    success, feature_count = self.export_dxf(
                        source,
                        expression,
                        output_file,
                        context,
                        feedback
                    )

                    if not success:
                        break

                    feedback.pushInfo(
                        f'Created DXF: {output_file} '
                        f'({feature_count} features)'
                    )

                else:

                    temp_result = None

                    try:

                        temp_result = processing.run(
                            'native:extractbyexpression',
                            {
                                'EXPRESSION': expression,
                                'INPUT': parameters[self.INPUT],
                                'OUTPUT': 'memory:'
                            },
                            context=context,
                            feedback=feedback
                        )

                        if feedback.isCanceled():
                            break

                        processing.run(
                            'native:savefeatures',
                            {
                                'INPUT': temp_result['OUTPUT'],
                                'OUTPUT': output_file
                            },
                            context=context,
                            feedback=feedback
                        )

                        feedback.pushInfo(
                            f'Created {output_format} file: '
                            f'{output_file}'
                        )

                    finally:

                        if temp_result is not None:
                            del temp_result

                        gc.collect()

                outputs[value] = output_file

                feedback.setProgress(int((i + 1) * total))

            feedback.pushInfo(
                f'Processing finished. '
                f'{len(outputs)} output files created.'
            )

            return {
                'OUTPUT_FOLDER': output_folder,
                'OUTPUT_LAYERS': outputs
            }

        except Exception as e:

            feedback.reportError(
                f'Error during processing: {str(e)}'
            )

            raise QgsProcessingException(str(e))


def createInstance():
    return SplitVectorLayer()
import os
import re

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon

from qgis.core import (
    QgsProcessing,
    QgsFeatureSink,
    QgsProcessingException,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsGeometry,
)


class RoundCoordinatesAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'
    DECIMALS = 9  # Number of decimal places to round to

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return RoundCoordinatesAlgorithm()

    def name(self):
        return 'round_coordinates'

    def displayName(self):
        return self.tr('Vetro Projection Tool by JGN')

    # ⬇ Empty group = appears directly under "Cable Passthrough"
    def group(self):
        return ''

    def groupId(self):
        return ''

    # ⬇ ADD THIS — icon for the tool
    def icon(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), 'icon.png'
        )
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr(
            "Rounds all vertex coordinates of any geometry type "
            "to 9 decimal places."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Input layer'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Output layer')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(
            parameters, self.INPUT, context
        )
        if source is None:
            raise QgsProcessingException(
                self.invalidSourceError(parameters, self.INPUT)
            )

        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            source.fields(),
            source.wkbType(),
            source.sourceCrs()
        )
        if sink is None:
            raise QgsProcessingException(
                self.invalidSinkError(parameters, self.OUTPUT)
            )

        total = (
            100.0 / source.featureCount()
            if source.featureCount() else 0
        )

        for current, feature in enumerate(source.getFeatures()):

            if feedback.isCanceled():
                break

            geom = feature.geometry()
            if geom is None or geom.isEmpty():
                continue

            wkt = geom.asWkt()
            rounded_wkt = self._round_wkt(wkt, self.DECIMALS)
            new_geom = QgsGeometry.fromWkt(rounded_wkt)
            feature.setGeometry(new_geom)

            sink.addFeature(feature, QgsFeatureSink.FastInsert)
            feedback.setProgress(int(current * total))

        return {self.OUTPUT: dest_id}

    def _round_wkt(self, wkt, decimals):
        def replacer(match):
            return str(round(float(match.group()), decimals))

        return re.sub(
            r"[-+]?\d*\.\d+|\d+", replacer, wkt
        )
import os

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

from qgis.PyQt.QtCore import QCoreApplication, QVariant

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
    QgsWkbTypes,
    QgsGeometry,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsDistanceArea,
    QgsProject,
    QgsSpatialIndex
)


class DuctAndSlackPoints(QgsProcessingAlgorithm):

    INPUT = 'INPUT'
    DUCT_POINTS = 'DUCT_POINTS'
    SLACK_POINTS = 'SLACK_POINTS'
    START_OFFSET = 'START_OFFSET'
    END_OFFSET = 'END_OFFSET'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return DuctAndSlackPoints()

    def name(self):
        return 'duct_and_slack_points'

    def displayName(self):
        return self.tr('Duct & Slack Points update by Iqwan')

    # ⬇ Empty group = appears directly under "Cable Passthrough"
    def group(self):
        return ''

    def groupId(self):
        return ''
    
     # ⬇ ADD THIS
    def icon(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), 'icon.png'
        )
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr(
            'Creates point features from line start/end points.\n\n'
            'Duct Points and Slack Points can be used independently '
            'or together.\n\n'

            'Duct Points only:\n'
            '- Creates Start Points\n'
            '- Uses Start Offset\n'
            '- Adds Duct, Duct color and Numbering fields\n\n'

            'Slack Points only:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Slackloop and Slackloop Colour fields\n'
            '- Slackloop is fixed at 50\n'
            '- Slackloop Colour is determined by:\n'
            '  F2 Distribution = 4\n'
            '  48 Fibers = 1\n'
            '  144 Fibers = 2\n'
            '  288 Fibers = 3\n\n'

            'Duct Points + Slack Points:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Duct, Duct color, Numbering, '
            'Slackloop and Slackloop Colour fields.'
        )

    def initAlgorithm(self, config=None):

        # =========================================================
        # INPUT
        # =========================================================

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Input line layer'),
                [QgsProcessing.TypeVectorLine]
            )
        )

        # =========================================================
        # DUCT POINTS
        # =========================================================

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.DUCT_POINTS,
                self.tr('Create Duct Points'),
                defaultValue=True
            )
        )

        # =========================================================
        # SLACK POINTS
        # =========================================================

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SLACK_POINTS,
                self.tr('Create Slack Points'),
                defaultValue=False
            )
        )

        # =========================================================
        # START OFFSET
        # =========================================================

        self.addParameter(
            QgsProcessingParameterNumber(
                self.START_OFFSET,
                self.tr('Start Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        # =========================================================
        # END OFFSET
        # =========================================================

        self.addParameter(
            QgsProcessingParameterNumber(
                self.END_OFFSET,
                self.tr('End Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        # =========================================================
        # OUTPUT
        # =========================================================

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Output point layer'),
                QgsProcessing.TypeVectorPoint
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        # =========================================================
        # GET INPUT
        # =========================================================

        source = self.parameterAsSource(
            parameters,
            self.INPUT,
            context
        )

        if source is None:
            raise QgsProcessingException(
                self.tr(
                    'Could not load the input line layer.'
                )
            )

        # =========================================================
        # GET OPTIONS
        # =========================================================

        duct_points = self.parameterAsBool(
            parameters,
            self.DUCT_POINTS,
            context
        )

        slack_points = self.parameterAsBool(
            parameters,
            self.SLACK_POINTS,
            context
        )

        start_offset_deg = self.parameterAsDouble(
            parameters,
            self.START_OFFSET,
            context
        )

        end_offset_deg = self.parameterAsDouble(
            parameters,
            self.END_OFFSET,
            context
        )

        # =========================================================
        # VALIDATION
        # =========================================================

        if not duct_points and not slack_points:
            raise QgsProcessingException(
                self.tr(
                    'Please enable at least one option: '
                    'Duct Points or Slack Points.'
                )
            )

        # =========================================================
        # DISTANCE CALCULATOR
        # =========================================================

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')

        # Approximate metres per degree
        metres_per_degree = 111319.9

        # Start offset
        start_offset_m = (
            start_offset_deg *
            metres_per_degree
        )

        # End offset
        end_offset_m = (
            end_offset_deg *
            metres_per_degree
        )

        # Convert metres to source CRS units
        start_offset_m = da.convertLengthMeasurement(
            start_offset_m,
            source.sourceCrs().mapUnits()
        )

        end_offset_m = da.convertLengthMeasurement(
            end_offset_m,
            source.sourceCrs().mapUnits()
        )

        # =========================================================
        # CREATE OUTPUT FIELDS
        # =========================================================

        fields = source.fields()

        # =========================================================
        # DUCT FIELDS
        # =========================================================

        if duct_points:

            fields.append(
                QgsField(
                    'Duct',
                    QVariant.Int
                )
            )

            fields.append(
                QgsField(
                    'Duct color',
                    QVariant.Int
                    
                )
            )

            fields.append(
                QgsField(
                    'Numbering',
                    QVariant.Int
                )
            )


        # =========================================================
        # SLACKLOOP FIELDS
        # =========================================================

        if slack_points:

            # Slackloop
            fields.append(
                QgsField(
                    'Slackloop',
                    QVariant.Int
                )
            )

            # Slackloop Colour
            fields.append(
                QgsField(
                    'Slackloop Colour',
                    QVariant.Int
                )
            )

        # =========================================================
        # CREATE OUTPUT
        # =========================================================

        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.Point,
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(
                self.tr(
                    'Could not create output layer.'
                )
            )

        # =========================================================
        # FIND INPUT FIELDS
        # =========================================================

        # v_layer field
        v_layer_index = source.fields().indexOf(
            'v_layer'
        )

        # Fiber Capacity field
        fiber_capacity_index = source.fields().indexOf(
            'Fiber Capacity'
        )

        # =========================================================
        # VALIDATE REQUIRED FIELDS
        # =========================================================

        if slack_points:

            if fiber_capacity_index < 0:
                raise QgsProcessingException(
                    self.tr(
                        'The input layer does not contain a '
                        '"Fiber Capacity" field.'
                    )
                )

        # =========================================================
        # PROCESS FEATURES
        # =========================================================

        total = source.featureCount()

        if total > 0:
            progress_step = 100.0 / total
        else:
            progress_step = 0

        for current, feature in enumerate(
            source.getFeatures()
        ):

            if feedback.isCanceled():
                break

            # =====================================================
            # GET GEOMETRY
            # =====================================================

            geom = feature.geometry()

            if geom is None or geom.isEmpty():
                continue

            # =====================================================
            # GET LINE LENGTH
            # =====================================================

            line_length = geom.length()

            if line_length <= 0:
                continue

            # =====================================================
            # DETERMINE v_layer VALUE
            # =====================================================

            v_layer_value = None

            if v_layer_index >= 0:

                v_layer_value = feature.attribute(
                    v_layer_index
                )

                if v_layer_value is not None:

                    v_layer_value = str(
                        v_layer_value
                    ).strip()

            # =====================================================
            # DETERMINE DUCT COLOR
            # =====================================================

            duct_color_value = None

            if duct_points:

                if v_layer_value == 'Backbone':

                    duct_color_value = '1'

                elif v_layer_value == 'F1 Lateral':

                    duct_color_value = '2'

                elif v_layer_value == 'F2 Distribution':

                    duct_color_value = '3'

            # =====================================================
            # DETERMINE SLACKLOOP COLOUR
            # =====================================================

            slackloop_colour_value = None

            if slack_points:

                # -------------------------------------------------
                # PRIORITY 1:
                # F2 Distribution = 4
                # -------------------------------------------------

                if v_layer_value == 'F2 Distribution':

                    slackloop_colour_value = 4

                # -------------------------------------------------
                # PRIORITY 2:
                # Fiber Capacity
                # -------------------------------------------------

                else:

                    fiber_capacity_value = feature.attribute(
                        fiber_capacity_index
                    )

                    if fiber_capacity_value is not None:

                        fiber_capacity_text = str(
                            fiber_capacity_value
                        ).strip()

                        # Normalize the Fiber Capacity value.
                        #
                        # Examples:
                        # 48
                        # 48 Fiber
                        # 48 Fibers
                        # 144
                        # 144 Fiber
                        # 144 Fibers
                        # 288
                        # 288 Fiber
                        # 288 Fibers

                        fiber_capacity_text = (
                            fiber_capacity_text
                            .lower()
                            .replace('fibers', '')
                            .replace('fiber', '')
                            .strip()
                        )

                        # -----------------------------------------
                        # 48 Fibers = Colour 1
                        # -----------------------------------------

                        if fiber_capacity_text == '48':

                            slackloop_colour_value = 1

                        # -----------------------------------------
                        # 144 Fibers = Colour 2
                        # -----------------------------------------

                        elif fiber_capacity_text == '144':

                            slackloop_colour_value = 2

                        # -----------------------------------------
                        # 288 Fibers = Colour 3
                        # -----------------------------------------

                        elif fiber_capacity_text == '288':

                            slackloop_colour_value = 3

                        # -----------------------------------------
                        # Other = NULL
                        # -----------------------------------------

                        else:

                            slackloop_colour_value = None

            # =====================================================
            # START POINT
            # =====================================================

            start_dist = min(
                start_offset_m,
                line_length
            )

            start_geom = geom.interpolate(
                start_dist
            )

            if not start_geom.isEmpty():

                start_point = start_geom.asPoint()

                start_feature = QgsFeature(fields)

                start_feature.setGeometry(
                    QgsGeometry.fromPointXY(
                        start_point
                    )
                )

                # =================================================
                # ORIGINAL ATTRIBUTES
                # =================================================

                attributes = feature.attributes()

                # =================================================
                # DUCT ATTRIBUTES
                # =================================================

                if duct_points:

                    # Duct
                    attributes.append(None)

                    # Duct color
                    attributes.append(
                        duct_color_value
                    )

                    # Numbering
                    attributes.append(None)

                # =================================================
                # SLACKLOOP ATTRIBUTES
                # =================================================

                if slack_points:

                    # Slackloop = 50
                    attributes.append(50)

                    # Slackloop Colour
                    attributes.append(
                        slackloop_colour_value
                    )

                # =================================================
                # SET START POINT ATTRIBUTES
                # =================================================

                start_feature.setAttributes(
                    attributes
                )

                sink.addFeature(
                    start_feature,
                    QgsFeatureSink.FastInsert
                )

            # =====================================================
            # END POINT
            # =====================================================

            if slack_points:

                end_dist = max(
                    0,
                    line_length - end_offset_m
                )

                end_geom = geom.interpolate(
                    end_dist
                )

                if not end_geom.isEmpty():

                    end_point = end_geom.asPoint()

                    end_feature = QgsFeature(fields)

                    end_feature.setGeometry(
                        QgsGeometry.fromPointXY(
                            end_point
                        )
                    )

                    # =================================================
                    # ORIGINAL ATTRIBUTES
                    # =================================================

                    end_attributes = feature.attributes()

                    # =================================================
                    # DUCT ATTRIBUTES
                    # =================================================

                    if duct_points:

                        # Duct
                        end_attributes.append(None)

                        # Duct color
                        end_attributes.append(
                            duct_color_value
                        )

                        # Numbering
                        end_attributes.append(None)

                    # =================================================
                    # SLACKLOOP ATTRIBUTES
                    # =================================================

                    # Slackloop = 50
                    end_attributes.append(50)

                    # Slackloop Colour
                    end_attributes.append(
                        slackloop_colour_value
                    )

                    # =================================================
                    # SET END POINT ATTRIBUTES
                    # =================================================

                    end_feature.setAttributes(
                        end_attributes
                    )

                    sink.addFeature(
                        end_feature,
                        QgsFeatureSink.FastInsert
                    )

            # =====================================================
            # PROGRESS
            # =====================================================

            feedback.setProgress(
                int(current * progress_step)
            )

        # =========================================================
        # RETURN OUTPUT
        # =========================================================

        return {
            self.OUTPUT: dest_id
        }
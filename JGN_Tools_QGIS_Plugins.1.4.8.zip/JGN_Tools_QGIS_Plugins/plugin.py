import os

from qgis.core import QgsApplication, QgsProcessingProvider
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.PyQt.QtGui import QIcon

from .feature_id_matcher_algorithm import FeatureIDMatcher
from .duct_and_slack_points import DuctAndSlackPoints
from .vetro_projection_tool import RoundCoordinatesAlgorithm
from .split_vector_layer import SplitVectorLayer


def _icon_path():
    """Return the absolute path to icon.png inside the plugin folder."""
    return os.path.join(os.path.dirname(__file__), 'icon.png')


class CablePassthroughPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.menu = None

    def initProcessing(self):
        self.provider = CablePassthroughProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

        # Create a menu that lists all tools
        self.menu = QMenu('JGN Tools', self.iface.mainWindow())
        self.menu.setIcon(QIcon(_icon_path()))

        # Define all tools: (menu label, algorithm id)
        tools = [
            ('Cable Passthrough (Attribute Tool)',
             'cable_passthrough:feature_id_matcher'),
            ('Duct & Slack Points',
             'cable_passthrough:duct_and_slack_points'),
            ('Vetro Projection Tool',
             'cable_passthrough:round_coordinates'),
            ('Split Vector Layer (Advanced)',
             'cable_passthrough:splitvectorlayer'),
        ]

        for label, alg_id in tools:
            action = self.menu.addAction(label)
            # Bind alg_id to the slot to avoid late-binding closure issue
            action.triggered.connect(
                lambda checked=False, a=alg_id: self.run_algorithm(a)
            )

        # Add the menu to the Vector menu and as a toolbar button
        self.iface.addPluginToVectorMenu('&JGN Tools', self.menu.menuAction())

        # Optional: add a toolbar button that shows the same menu
        self.toolbar_action = QAction(
            QIcon(_icon_path()), 'JGN Tools', self.iface.mainWindow()
        )
        self.toolbar_action.setMenu(self.menu)
        self.toolbar_action.setPopupMode(
            QAction.MenuButtonPopup  # or InstantPopup for one-click dropdown
        )
        self.iface.addToolBarIcon(self.toolbar_action)

    def unload(self):
        self.iface.removePluginVectorMenu('&JGN Tools', self.menu.menuAction())
        self.iface.removeToolBarIcon(self.toolbar_action)

        if self.menu is not None:
            self.menu.deleteLater()
            self.menu = None

        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

    def run_algorithm(self, alg_id):
        alg = QgsApplication.processingRegistry().algorithmById(alg_id)

        if alg is None:
            self.iface.messageBar().pushCritical(
                'JGN Tools',
                f'Algorithm not found: {alg_id}'
            )
            return

        from qgis import processing
        try:
            processing.execAlgorithmDialog(alg_id, {})
        except Exception as e:
            self.iface.messageBar().pushCritical('JGN Tools', str(e))


class CablePassthroughProvider(QgsProcessingProvider):

    def id(self):
        return 'cable_passthrough'

    def name(self):
        return 'JGN Tools'

    def longName(self):
        return 'JGN Tools'

    def icon(self):
        return QIcon(_icon_path())

    def loadAlgorithms(self):
        self.addAlgorithm(FeatureIDMatcher())
        self.addAlgorithm(DuctAndSlackPoints())
        self.addAlgorithm(RoundCoordinatesAlgorithm())
        self.addAlgorithm(SplitVectorLayer())
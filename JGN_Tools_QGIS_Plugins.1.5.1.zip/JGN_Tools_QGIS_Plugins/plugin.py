import os

from qgis.core import QgsApplication, QgsProcessingProvider
from qgis.PyQt.QtWidgets import QMenu, QToolButton
from qgis.PyQt.QtGui import QIcon

from .feature_id_matcher_algorithm import FeatureIDMatcher
from .duct_and_slack_points import DuctAndSlackPoints
from .vetro_projection_tool import RoundCoordinatesAlgorithm
from .split_vector_layer import SplitVectorLayer


def _icon_path():
    return os.path.join(os.path.dirname(__file__), 'icon.png')


class CablePassthroughPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.menu = None
        self.tool_button = None
        self.toolbar = None

    def initProcessing(self):
        self.provider = CablePassthroughProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

        # Build menu with all tools
        self.menu = QMenu('JGN Tools', self.iface.mainWindow())
        self.menu.setIcon(QIcon(_icon_path()))

        tools = [
            ('Cable Passthrough (Attribute Tool) by JGN',
             'cable_passthrough:feature_id_matcher',
             _icon_path()),
            ('Duct & Slack Points updated by Iqwan,
             'cable_passthrough:duct_and_slack_points',
             _icon_path()),
            ('Vetro Projection Tool by JGN',
             'cable_passthrough:round_coordinates',
             _icon_path()),
            ('Split Vector Layer (Advanced) by JGN',
             'cable_passthrough:splitvectorlayer',
             _icon_path()),
        ]

        for label, alg_id, icon_path in tools:
            action = self.menu.addAction(QIcon(icon_path), label)
            action.triggered.connect(
                lambda checked=False, a=alg_id: self.run_algorithm(a)
            )

        # Add menu to Vector menu
        self.iface.addPluginToVectorMenu(
            '&JGN Tools', self.menu.menuAction()
        )

        # Build toolbar button with dropdown menu
        self.tool_button = QToolButton()
        self.tool_button.setIcon(QIcon(_icon_path()))
        self.tool_button.setText('JGN Tools')
        self.tool_button.setToolTip('JGN Tools')
        self.tool_button.setPopupMode(QToolButton.MenuButtonPopup)
        self.tool_button.setMenu(self.menu)

        self.toolbar = self.iface.addToolBar('JGN Tools')
        self.toolbar.addWidget(self.tool_button)

    def unload(self):
        self.iface.removePluginVectorMenu(
            '&JGN Tools', self.menu.menuAction()
        )

        if self.toolbar is not None:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            self.toolbar.deleteLater()
            self.toolbar = None

        if self.menu is not None:
            self.menu.deleteLater()
            self.menu = None

        self.tool_button = None

        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(
                self.provider
            )
            self.provider = None

    def run_algorithm(self, alg_id):
        alg = QgsApplication.processingRegistry().algorithmById(alg_id)

        if alg is None:
            self.iface.messageBar().pushCritical(
                'JGN Tools',
                f'Algorithm not found: {alg_id}'
            )
            return

        from qgis import processing
        try:
            processing.execAlgorithmDialog(alg_id, {})
        except Exception as e:
            self.iface.messageBar().pushCritical('JGN Tools', str(e))


class CablePassthroughProvider(QgsProcessingProvider):

    def id(self):
        return 'cable_passthrough'

    def name(self):
        return 'JGN Tools'

    def longName(self):
        return 'JGN Tools'

    def icon(self):
        return QIcon(_icon_path())

    def loadAlgorithms(self):
        self.addAlgorithm(FeatureIDMatcher())
        self.addAlgorithm(DuctAndSlackPoints())
        self.addAlgorithm(RoundCoordinatesAlgorithm())
        self.addAlgorithm(SplitVectorLayer())
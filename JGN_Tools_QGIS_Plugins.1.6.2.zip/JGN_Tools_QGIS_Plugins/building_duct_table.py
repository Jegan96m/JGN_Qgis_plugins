import os

from qgis.PyQt.QtCore import QCoreApplication, Qt, QVariant
from qgis.PyQt.QtGui import QFont

from qgis.core import (
    QgsProcessing,
    QgsProcessingException,
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterLayout,
    QgsProcessingParameterString,
    QgsLayoutItemAttributeTable,
    QgsLayoutFrame,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsUnitTypes,
    QgsLayoutTableColumn,
    QgsLayoutTable,
    QgsLayoutItemMap,
)


class BuildNumberingTables(QgsProcessingAlgorithm):

    LAYER  = 'LAYER'
    LAYOUT = 'LAYOUT'
    MAP_ID = 'MAP_ID'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return BuildNumberingTables()

    def name(self):
        return 'buildnumberingtables'

    def displayName(self):
        return self.tr('Build Automatic Duct Table in Layout by JGN')

    def group(self):
        return self.tr('Layout tools')

    def groupId(self):
        return 'layouttools'

    def shortHelpString(self):
        return self.tr(
            "Creates one attribute-table frame per unique 'Numbering' value "
            "in the selected layout. Map item ID is optional — leave empty "
            "to use the first map found in the layout."
        )

    # Run in the main thread — layout objects are GUI-thread bound.
    def flags(self):
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    # ------------------------------------------------------------------
    # GUI: only 3 parameters
    # ------------------------------------------------------------------
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.LAYER,
            self.tr('Source layer'),
            [QgsProcessing.TypeVector]
        ))

        self.addParameter(QgsProcessingParameterLayout(
            self.LAYOUT,
            self.tr('Layout')
        ))

        self.addParameter(QgsProcessingParameterString(
            self.MAP_ID,
            self.tr('Map item ID (empty = first map)'),
            defaultValue='',
            optional=True
        ))

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        # ==============================================================
        # HARDCODED SETTINGS — edit these here if you ever need to change
        # ==============================================================
        FIELD_NAME       = 'Numbering'          # field used to split tables
        DISPLAY_FIELDS   = ['Duct', 'label']    # columns shown in each table
        START_X          = 364.0                # mm
        START_Y          = 78.0                 # mm
        TABLE_WIDTH      = 180.0                # mm
        TABLE_HEIGHT     = 60.0                 # mm
        GAP              = 5.0                  # mm between tables
        DUCT_COL_WIDTH   = 5                    # mm
        FONT_POINT_SIZE  = 8
        # ==============================================================

        layer = self.parameterAsVectorLayer(parameters, self.LAYER, context)
        if layer is None:
            raise QgsProcessingException(
                self.invalidSourceError(parameters, self.LAYER))

        layout = self.parameterAsLayout(parameters, self.LAYOUT, context)
        if layout is None:
            raise QgsProcessingException("Layout not found.")

        map_id = self.parameterAsString(parameters, self.MAP_ID, context).strip()

        # --- resolve map item ---
        map_item = layout.itemById(map_id) if map_id else None
        if map_item is None:
            for item in layout.items():
                if isinstance(item, QgsLayoutItemMap):
                    map_item = item
                    break
        if map_item is None:
            raise QgsProcessingException(
                "No map item found in the selected layout.")

        # --- validate split field ---
        field_idx = layer.fields().indexOf(FIELD_NAME)
        if field_idx < 0:
            raise QgsProcessingException(
                f"Field '{FIELD_NAME}' not found in layer.")
        is_text = layer.fields().field(FIELD_NAME).type() == QVariant.String

        # --- collect unique values (NULLs filtered out) ---
        unique_values = sorted({
            f[FIELD_NAME] for f in layer.getFeatures()
            if f[FIELD_NAME] is not None
        })
        if not unique_values:
            feedback.pushWarning(
                f"No non-null values found in '{FIELD_NAME}'. Nothing to do.")
            return {}

        feedback.pushInfo(
            f"Creating {len(unique_values)} table frames on layout "
            f"'{layout.name()}'.")

        total = 100.0 / len(unique_values)
        x_position = START_X

        # Hold Python refs so wrappers aren't GC'd mid-render.
        created_frames = []

        for i, value in enumerate(unique_values):
            if feedback.isCanceled():
                break

            value_sql = f"'{value}'" if is_text else value

            table = QgsLayoutItemAttributeTable.create(layout)
            table.setVectorLayer(layer)
            layout.addMultiFrame(table)

            table.setDisplayedFields(DISPLAY_FIELDS)
            table.setFilterFeatures(True)
            table.setFeatureFilter(f'"{FIELD_NAME}" = {value_sql}')
            table.setUniqueRowsOnly(True)
            table.setDisplayOnlyVisibleFeatures(True)
            table.setMap(map_item)

            # column formatting
            cols = [col.clone() for col in table.columns()]
            for col in cols:
                if col.attribute() == "Duct":
                    col.setHAlignment(Qt.AlignHCenter)
                    col.setVAlignment(Qt.AlignVCenter)
                    col.setWidth(DUCT_COL_WIDTH)
            table.setColumns(cols)

            sort_col = QgsLayoutTableColumn()
            sort_col.setAttribute("Duct")
            sort_col.setSortOrder(Qt.AscendingOrder)
            table.setSortColumns([sort_col])

            table.setHeaderMode(QgsLayoutTable.NoHeaders)
            table.setUseConditionalStyling(True)
            table.setEmptyTableBehavior(QgsLayoutTable.HideTable)

            font = QFont()
            font.setPointSize(FONT_POINT_SIZE)
            table.setContentFont(font)

            table.refreshAttributes()

            frame = QgsLayoutFrame(layout, table)
            frame.attemptMove(QgsLayoutPoint(
                x_position, START_Y, QgsUnitTypes.LayoutMillimeters))
            frame.attemptResize(QgsLayoutSize(
                TABLE_WIDTH, TABLE_HEIGHT, QgsUnitTypes.LayoutMillimeters))
            frame.setEnabled(True)
            layout.addLayoutItem(frame)
            table.addFrame(frame)

            created_frames.append(frame)

            x_position += GAP
            feedback.setProgress(int((i + 1) * total))

        layout.refresh()
        feedback.pushInfo("Done.")
        return {}
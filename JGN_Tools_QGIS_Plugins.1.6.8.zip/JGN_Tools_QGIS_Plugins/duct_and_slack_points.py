import os

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
    QgsWkbTypes,
    QgsGeometry,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsDistanceArea,
    QgsProject,
    QgsSpatialIndex
)


class DuctAndSlackPoints(QgsProcessingAlgorithm):

    INPUT = 'INPUT'
    DUCT_POINTS = 'DUCT_POINTS'
    SLACK_POINTS = 'SLACK_POINTS'
    START_OFFSET = 'START_OFFSET'
    END_OFFSET = 'END_OFFSET'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return DuctAndSlackPoints()

    def name(self):
        return 'duct_and_slack_points'

    def displayName(self):
        return self.tr('Duct & Slack Points update by Iqwan')

    def group(self):
        return ''

    def groupId(self):
        return ''

    def icon(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), 'icon.png'
        )
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr(
            'Creates point features from line start/end points.\n\n'
            'Duct Points and Slack Points can be used independently '
            'or together.\n\n'

            'Duct Points only:\n'
            '- Creates Start Points\n'
            '- Uses Start Offset\n'
            '- Adds Duct, Duct color and Numbering fields\n\n'

            'Slack Points only:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Slackloop and Slackloop Colour fields\n'
            '- Slackloop is fixed at 50\n'
            '- Slackloop Colour is determined by:\n'
            '  F2 Distribution = 4\n'
            '  48 Fibers = 1\n'
            '  144 Fibers = 2\n'
            '  288 Fibers = 3\n\n'

            'Duct Points + Slack Points:\n'
            '- Creates Start and End Points\n'
            '- Uses Start Offset and End Offset\n'
            '- Adds Duct, Duct color, Numbering, '
            'Slackloop and Slackloop Colour fields.\n\n'

            'Label field:\n'
            '- Always added to output.\n'
            '- F1 Lateral / F2 Distribution use Material Length:\n'
            '  F1 LAT-<ID>\\n<FC>F, <ML>ft \n'
            '  F2 DIST-<ID>\\n<FC>F, <ML>ft \n'
            '- Backbone uses Total Length + Slack Loop\n'
            '  (Backbone has no Material Length field):\n'
            '  F0 BB-<ID>\\n<FC>F, <TL+SL>ft \n'
            '- Blank for other v_layer values.'
        )

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Input line layer'),
                [QgsProcessing.TypeVectorLine]
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.DUCT_POINTS,
                self.tr('Create Duct Points'),
                defaultValue=True
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SLACK_POINTS,
                self.tr('Create Slack Points'),
                defaultValue=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.START_OFFSET,
                self.tr('Start Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.END_OFFSET,
                self.tr('End Offset (degrees)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0.0,
                defaultValue=0.0
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Output point layer'),
                QgsProcessing.TypeVectorPoint
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(
            parameters, self.INPUT, context
        )

        if source is None:
            raise QgsProcessingException(
                self.tr('Could not load the input line layer.')
            )

        duct_points = self.parameterAsBool(
            parameters, self.DUCT_POINTS, context
        )

        slack_points = self.parameterAsBool(
            parameters, self.SLACK_POINTS, context
        )

        start_offset_deg = self.parameterAsDouble(
            parameters, self.START_OFFSET, context
        )

        end_offset_deg = self.parameterAsDouble(
            parameters, self.END_OFFSET, context
        )

        if not duct_points and not slack_points:
            raise QgsProcessingException(
                self.tr(
                    'Please enable at least one option: '
                    'Duct Points or Slack Points.'
                )
            )

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')

        metres_per_degree = 111319.9

        start_offset_m = start_offset_deg * metres_per_degree
        end_offset_m = end_offset_deg * metres_per_degree

        start_offset_m = da.convertLengthMeasurement(
            start_offset_m, source.sourceCrs().mapUnits()
        )

        end_offset_m = da.convertLengthMeasurement(
            end_offset_m, source.sourceCrs().mapUnits()
        )

        # =========================================================
        # CREATE OUTPUT FIELDS
        # =========================================================

        fields = source.fields()

        if duct_points:
            fields.append(QgsField('Duct', QVariant.Int, 'integer'))
            fields.append(QgsField('Duct color', QVariant.Int))
            fields.append(QgsField('Numbering', QVariant.Int, 'integer'))

        if slack_points:
            fields.append(QgsField('Slackloop', QVariant.Int))
            fields.append(QgsField('Slackloop Colour', QVariant.Int))

        fields.append(QgsField('label', QVariant.String, 'string'))

        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.Point,
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(
                self.tr('Could not create output layer.')
            )

        # =========================================================
        # FIND INPUT FIELDS
        # (-1 means the field does not exist in the source)
        # =========================================================

        v_layer_index = source.fields().indexOf('v_layer')
        fiber_capacity_index = source.fields().indexOf('Fiber Capacity')
        id_index = source.fields().indexOf('ID')
        material_length_index = source.fields().indexOf('Material Length')
        total_length_index = source.fields().indexOf('Total Length')
        slack_loop_index = source.fields().indexOf('Slack Loop')

        # =========================================================
        # VALIDATE REQUIRED FIELDS
        #
        # NOTE:
        # "Material Length" is only needed for F1 / F2.
        # "Total Length" + "Slack Loop" are only needed for Backbone.
        # Backbone has no Material Length field, so we do NOT require it
        # globally — missing values are handled per-feature below.
        # =========================================================

        if slack_points:
            if fiber_capacity_index < 0:
                raise QgsProcessingException(
                    self.tr(
                        'The input layer does not contain a '
                        '"Fiber Capacity" field.'
                    )
                )

        if id_index < 0:
            raise QgsProcessingException(
                self.tr(
                    'The input layer does not contain an "ID" field '
                    '(required for the label).'
                )
            )

        # =========================================================
        # HELPER: read attribute safely even if field is missing
        # =========================================================

        def safe_attr(feat, idx):
            if idx < 0:
                return None
            return feat.attribute(idx)

        # =========================================================
        # PROCESS FEATURES
        # =========================================================

        total = source.featureCount()
        progress_step = (100.0 / total) if total > 0 else 0

        for current, feature in enumerate(source.getFeatures()):

            if feedback.isCanceled():
                break

            geom = feature.geometry()

            if geom is None or geom.isEmpty():
                continue

            line_length = geom.length()

            if line_length <= 0:
                continue

            # =====================================================
            # v_layer
            # =====================================================

            v_layer_value = None
            if v_layer_index >= 0:
                v_layer_value = feature.attribute(v_layer_index)
                if v_layer_value is not None:
                    v_layer_value = str(v_layer_value).strip()

            # =====================================================
            # DUCT COLOR
            # =====================================================

            duct_color_value = None
            if duct_points:
                if v_layer_value == 'Backbone':
                    duct_color_value = '1'
                elif v_layer_value == 'F1 Lateral':
                    duct_color_value = '2'
                elif v_layer_value == 'F2 Distribution':
                    duct_color_value = '3'

            # =====================================================
            # SLACKLOOP COLOUR
            # =====================================================

            slackloop_colour_value = None

            if slack_points:

                if v_layer_value == 'F2 Distribution':
                    slackloop_colour_value = 4
                else:
                    fiber_capacity_value = safe_attr(
                        feature, fiber_capacity_index
                    )

                    if fiber_capacity_value is not None:
                        fiber_capacity_text = str(
                            fiber_capacity_value
                        ).strip()

                        fiber_capacity_text = (
                            fiber_capacity_text
                            .lower()
                            .replace('fibers', '')
                            .replace('fiber', '')
                            .strip()
                        )

                        if fiber_capacity_text == '48':
                            slackloop_colour_value = 1
                        elif fiber_capacity_text == '144':
                            slackloop_colour_value = 2
                        elif fiber_capacity_text == '288':
                            slackloop_colour_value = 3
                        else:
                            slackloop_colour_value = None

            # =====================================================
            # LABEL
            # =====================================================

            label_value = None

            if v_layer_value in (
                'F1 Lateral', 'F2 Distribution', 'Backbone'
            ):

                # ID
                id_value = ''
                raw_id = safe_attr(feature, id_index)
                if raw_id is not None:
                    id_value = str(raw_id).strip()

                # Fiber Capacity (raw display value)
                fiber_capacity_display = ''
                raw_fc = safe_attr(feature, fiber_capacity_index)
                if raw_fc is not None:
                    fiber_capacity_display = str(raw_fc).strip()

                # ---------------------------------------------
                # Length value differs by v_layer
                # ---------------------------------------------

                length_rounded = ''

                if v_layer_value == 'Backbone':
                    # Backbone has NO Material Length.
                    # Use: round("Total Length" + "Slack Loop")
                    raw_total = safe_attr(feature, total_length_index)
                    raw_slack = safe_attr(feature, slack_loop_index)

                    try:
                        total_val = (
                            float(raw_total)
                            if raw_total is not None else 0.0
                        )
                        slack_val = (
                            float(raw_slack)
                            if raw_slack is not None else 0.0
                        )
                        length_rounded = str(
                            int(round(total_val + slack_val))
                        )
                    except (ValueError, TypeError):
                        length_rounded = ''

                else:
                    # F1 / F2 use: round("Material Length")
                    raw_ml = safe_attr(
                        feature, material_length_index
                    )
                    if raw_ml is not None:
                        try:
                            length_rounded = str(
                                int(round(float(raw_ml)))
                            )
                        except (ValueError, TypeError):
                            length_rounded = str(raw_ml).strip()

                # ---------------------------------------------
                # Prefix by v_layer
                # ---------------------------------------------

                if v_layer_value == 'F1 Lateral':
                    prefix = 'F1 LAT-'
                elif v_layer_value == 'F2 Distribution':
                    prefix = 'F2 DIST-'
                else:  # Backbone
                    prefix = 'F0 BB-'

                label_value = (
                    prefix + id_value
                    + '\n'
                    + fiber_capacity_display + 'F'
                    + ', '
                    + length_rounded + 'ft'
                    + ' '
                )

            # =====================================================
            # START POINT
            # =====================================================

            start_dist = min(start_offset_m, line_length)
            start_geom = geom.interpolate(start_dist)

            if not start_geom.isEmpty():

                start_point = start_geom.asPoint()
                start_feature = QgsFeature(fields)
                start_feature.setGeometry(
                    QgsGeometry.fromPointXY(start_point)
                )

                attributes = feature.attributes()

                if duct_points:
                    attributes.append(0)               # Duct
                    attributes.append(duct_color_value)   # Duct color
                    attributes.append(0)               # Numbering

                if slack_points:
                    attributes.append(50)                 # Slackloop
                    attributes.append(slackloop_colour_value)

                attributes.append(label_value)            # Label

                start_feature.setAttributes(attributes)

                sink.addFeature(
                    start_feature, QgsFeatureSink.FastInsert
                )

            # =====================================================
            # END POINT
            # =====================================================

            if slack_points:

                end_dist = max(0, line_length - end_offset_m)
                end_geom = geom.interpolate(end_dist)

                if not end_geom.isEmpty():

                    end_point = end_geom.asPoint()
                    end_feature = QgsFeature(fields)
                    end_feature.setGeometry(
                        QgsGeometry.fromPointXY(end_point)
                    )

                    end_attributes = feature.attributes()

                    if duct_points:
                        end_attributes.append(None)
                        end_attributes.append(duct_color_value)
                        end_attributes.append(None)

                    end_attributes.append(50)
                    end_attributes.append(slackloop_colour_value)

                    end_attributes.append(label_value)

                    end_feature.setAttributes(end_attributes)

                    sink.addFeature(
                        end_feature, QgsFeatureSink.FastInsert
                    )

            feedback.setProgress(int(current * progress_step))

        return {self.OUTPUT: dest_id}
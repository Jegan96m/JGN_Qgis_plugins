import os

from qgis.PyQt.QtCore import QCoreApplication, Qt, QVariant
from qgis.PyQt.QtGui import QFont, QIcon
from qgis.core import QgsProject

from qgis.core import (
    QgsProcessing,
    QgsProcessingException,
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterLayout,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsLayoutItemAttributeTable,
    QgsLayoutFrame,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsUnitTypes,
    QgsLayoutTableColumn,
    QgsLayoutTable,
    QgsLayoutItemMap,
)


class BuildNumberingTables(QgsProcessingAlgorithm):

    LAYER       = 'LAYER'
    LAYOUT      = 'LAYOUT'
    MAP_ID      = 'MAP_ID'
    FONT_SIZE   = 'FONT_SIZE'
    DUCT_WIDTH  = 'DUCT_WIDTH'
    LABEL_WIDTH = 'LABEL_WIDTH'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return BuildNumberingTables()

    def name(self):
        return 'buildnumberingtables'

    def displayName(self):
        return self.tr('Build Automatic Duct Table in Layout by JGN')

    def group(self):
        return ''

    def groupId(self):
        return ''

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        return QIcon(icon_path)

    def shortHelpString(self):
        return self.tr(
            "Creates a table frame ONLY for each (id_2, Numbering) pair that "
            "actually has data. Empty pairs are never created. On each atlas "
            "page, only that page's frames have rows; the rest are hidden."
        )

    def flags(self):
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    # ------------------------------------------------------------------
    # GUI
    # ------------------------------------------------------------------
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.LAYER, self.tr('Source layer'), [QgsProcessing.TypeVector]))
        self.addParameter(QgsProcessingParameterLayout(
            self.LAYOUT, self.tr('Layout')))
        self.addParameter(QgsProcessingParameterString(
            self.MAP_ID, self.tr('Map item ID (empty = first map)'),
            defaultValue='', optional=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.FONT_SIZE,
            self.tr('Font size (pt)'),
            QgsProcessingParameterNumber.Integer,
            defaultValue=8, minValue=1, maxValue=72))

        self.addParameter(QgsProcessingParameterNumber(
            self.DUCT_WIDTH,
            self.tr('"Duct" column width (mm)'),
            QgsProcessingParameterNumber.Double,
            defaultValue=5.0, minValue=0.1, maxValue=1000.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.LABEL_WIDTH,
            self.tr('"label" column width (mm)'),
            QgsProcessingParameterNumber.Double,
            defaultValue=40.0, minValue=0.1, maxValue=1000.0))

    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        # ==============================================================
        # HARDCODED SETTINGS
        # ==============================================================
        FIELD_NAME      = 'Numbering'
        ATLAS_FIELD     = 'id_2'
        DISPLAY_FIELDS  = ['Duct', 'label']
        START_X         = 364.0           # mm
        START_Y         = 78.0            # mm
        TABLE_WIDTH     = 230.0           # mm
        TABLE_HEIGHT    = 60.0            # mm
        GAP             = 5.0             # mm
        # ==============================================================

        # --- read user parameters ---
        font_size   = self.parameterAsInt(parameters, self.FONT_SIZE, context)
        duct_width  = self.parameterAsDouble(parameters, self.DUCT_WIDTH, context)
        label_width = self.parameterAsDouble(parameters, self.LABEL_WIDTH, context)

        layer = self.parameterAsVectorLayer(parameters, self.LAYER, context)
        if layer is None:
            raise QgsProcessingException(
                self.invalidSourceError(parameters, self.LAYER))

        layout = self.parameterAsLayout(parameters, self.LAYOUT, context)
        if layout is None:
            raise QgsProcessingException("Layout not found.")

        map_id = self.parameterAsString(parameters, self.MAP_ID, context).strip()

        # --- resolve map item ---
        map_item = layout.itemById(map_id) if map_id else None
        if map_item is None:
            for item in layout.items():
                if isinstance(item, QgsLayoutItemMap):
                    map_item = item
                    break
        if map_item is None:
            raise QgsProcessingException(
                "No map item found in the selected layout.")

        # --- validate fields ---
        if layer.fields().indexOf(FIELD_NAME) < 0:
            raise QgsProcessingException(
                f"Field '{FIELD_NAME}' not found in layer.")
        if layer.fields().indexOf(ATLAS_FIELD) < 0:
            raise QgsProcessingException(
                f"Field '{ATLAS_FIELD}' not found in layer.")
        is_text = layer.fields().field(FIELD_NAME).type() == QVariant.String

        # --------------------------------------------------------------
        # 1) Build the set of (id_2, Numbering) pairs that actually exist
        # --------------------------------------------------------------
        pairs = set()
        for f in layer.getFeatures():
            page_val = f[ATLAS_FIELD]
            num_val = f[FIELD_NAME]
            if page_val is None or num_val is None:
                continue
            pairs.add((page_val, num_val))

        if not pairs:
            raise QgsProcessingException(
                "No features with both fields non-null. Nothing to build.")

        sorted_pairs = sorted(pairs, key=lambda t: (t[0], t[1]))

        feedback.pushInfo(
            f"Found {len(sorted_pairs)} (id_2, Numbering) pairs with data. "
            f"Creating one frame per pair in layout '{layout.name()}'.")
        feedback.pushInfo(
            f"Font size: {font_size} pt | "
            f"Duct width: {duct_width} mm | "
            f"label width: {label_width} mm")

        # --------------------------------------------------------------
        # 2) Create one frame per existing pair
        # --------------------------------------------------------------
        total = 100.0 / len(sorted_pairs)
        x_position = START_X
        created_frames = []

        for i, (page_val, numbering) in enumerate(sorted_pairs):
            if feedback.isCanceled():
                break

            value_sql = f"'{numbering}'" if is_text else numbering
            page_sql = f"'{page_val}'" if isinstance(page_val, str) else page_val

            table = QgsLayoutItemAttributeTable.create(layout)
            table.setVectorLayer(layer)
            layout.addMultiFrame(table)

            table.setDisplayedFields(DISPLAY_FIELDS)
            table.setFilterFeatures(True)
            table.setFeatureFilter(
                f'@atlas_featureid = {page_sql} AND "{ATLAS_FIELD}" = {page_sql} AND '
                f'"{FIELD_NAME}" = {value_sql} '
                
            )
            table.setUniqueRowsOnly(True)
            table.setDisplayOnlyVisibleFeatures(True)
            table.setMap(map_item)

            # --- column formatting using user widths ---
            cols = [col.clone() for col in table.columns()]
            for col in cols:
                attr = col.attribute()
                if attr == "Duct":
                    col.setHAlignment(Qt.AlignHCenter)
                    col.setVAlignment(Qt.AlignVCenter)
                    col.setWidth(duct_width)
                elif attr == "label":
                    col.setWidth(label_width)
            table.setColumns(cols)

            sort_duct = QgsLayoutTableColumn()
            sort_duct.setAttribute("Duct")
            sort_duct.setSortOrder(Qt.AscendingOrder)
            table.setSortColumns([sort_duct])
            
            sort_numbering = QgsLayoutTableColumn()
            sort_numbering.setAttribute("Numbering")
            sort_numbering.setSortOrder(Qt.AscendingOrder)
            table.setSortColumns([sort_numbering])

            table.setHeaderMode(QgsLayoutTable.NoHeaders)
            table.setUseConditionalStyling(True)
            table.setEmptyTableBehavior(QgsLayoutTable.HideTable)

            font = QFont()
            font.setPointSize(font_size)
            table.setContentFont(font)
            table.refreshAttributes()

            frame = QgsLayoutFrame(layout, table)
            frame.attemptMove(QgsLayoutPoint(
                x_position, START_Y, QgsUnitTypes.LayoutMillimeters))
            frame.attemptResize(QgsLayoutSize(
                TABLE_WIDTH, TABLE_HEIGHT, QgsUnitTypes.LayoutMillimeters))
            frame.setEnabled(True)
            layout.addLayoutItem(frame)
            table.addFrame(frame)
            created_frames.append(frame)

            x_position += GAP
            feedback.setProgress(int((i + 1) * total))

        layout.refresh()
        feedback.pushInfo(
            f"Done. Created {len(created_frames)} frames "
            f"(one per existing (id_2, Numbering) pair).")
        return {}